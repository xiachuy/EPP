#include "robot.h"
#include "stm32f1xx_hal.h"
#include "gpio.h"
float L1=100;
float L2=100;
 float x,y;//x y �ֱ�Ϊ��е�۽����Ŀ��ֵ
 float r;
 float sigma3,sigma4,sigma5;
 float sigma1=-0.278*pi;
float sigma2=0.872;
 float T_sigma1;
 float T_sigma2;
int all_step_1;
int all_step_2;
int all_step_3;
float last_sigma1;
float last_sigma2;
float L1_sigma1;
float L2_sigma2;
float last_arm=0.8727; 
float current_sigma;
//�����е��
// HAL_GPIO_WritePin(GPIOB, DIR4_Pin, GPIO_PIN_SET);//DIR1 Z��͵�ƽ���޵��һ��ת��
 //HAL_GPIO_WritePin(GPIOB, DIR2_Pin, GPIO_PIN_SET);//DIR2 ��۸ߵ�ƽ��ʱ��ת��
 //HAL_GPIO_WritePin(GPIOB, DIR3_Pin, GPIO_PIN_RESET);//DIR3 С�۸ߵ�ƽ��ʱ��ת��
	//CalculateSModelLine(fre,period,ACCELERATED_SPEED_LENGTH,FRE_MAX,FRE_MIN,4);

float actan(float x,float y)
{
	float alpha;
	if (x>0)
    	alpha=atan(y/x);
	else if(x<0&&y>=0)
	     alpha=atan(y/x)+pi;
	else if (x<0&&y<0)
	     alpha=atan(y/x)-pi;
	else if (x==0&&y>0)
	    alpha=pi/2;
	else if (x==0&&y<0)
	    alpha=-pi/2;

	return alpha;

}

void robot_arm(float x,float y)
{
	
	float c2,s2,r;
	float beta,alpha;
	float sin_b,cos_b;
	r=sqrt(x*x+y*y);
	c2=((x*x+y*y-L1*L1-L2*L2)/(2*L1*L2));
	s2=sqrt(1-c2*c2);
	sigma2=actan(c2,s2);
	alpha=actan(x,y);
	sin_b=(L2*s2/r);
	cos_b=((L1+L2*c2)/r);
	beta=actan(cos_b,sin_b);
	sigma1=alpha-beta;
	if(sigma1<-pi)
	{
		sigma1=2*pi+sigma1;
	}
}

void motor_result(float x,float y)
{
	float a1,a2;
	last_sigma1=sigma1;
	last_sigma2=sigma2;
	a1=last_sigma1*180./3.14;
	a2=last_sigma2*180./3.14;
	robot_arm(x,y);

	if(sigma1>last_sigma1)
	{
		L1_sigma1=sigma1-last_sigma1;
		all_step_1=(fabs(L1_sigma1)*180/pi)/360*1600*48/20;
    HAL_GPIO_WritePin(GPIOB, DIR2_Pin, GPIO_PIN_SET);
	}
	else if(sigma1<last_sigma1)
	{
		L1_sigma1=sigma1-last_sigma1;
		all_step_1=(fabs(L1_sigma1)*180/pi)/360*1600*48/20;
		HAL_GPIO_WritePin(GPIOB, DIR2_Pin, GPIO_PIN_RESET);
	}

	current_sigma=L1_sigma1+last_arm;
	if(current_sigma<pi/6)
	{
			current_sigma=pi/6;
	}
	if(current_sigma>(pi-sigma2))
	{
		L2_sigma2=(pi-sigma2)-current_sigma; 
		last_arm= (pi-sigma2); 
		all_step_2=(fabs(L2_sigma2)*180/pi)/360*1600*48/20;	
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
	}
	else if (current_sigma<(pi-sigma2))
	{
		L2_sigma2=(pi-sigma2)-current_sigma; 
		last_arm= (pi-sigma2); 
		all_step_2=(fabs(L2_sigma2)*180/pi)/360*1600*48/20;	
   	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5,GPIO_PIN_RESET);
	}
}


