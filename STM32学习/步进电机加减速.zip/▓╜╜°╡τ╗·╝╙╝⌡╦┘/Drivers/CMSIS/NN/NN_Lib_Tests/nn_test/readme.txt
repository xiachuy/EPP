CMSIS DSP_Lib example arm_nnexample_nn_test for
  Cortex-M3, Cortex-M4 and Cortex-M7.

The example is configured for uVision Simulator.
